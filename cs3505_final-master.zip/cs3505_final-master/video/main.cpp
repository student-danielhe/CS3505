/**
 * This is the main file for building the .ass subtitle file to add to our Mario video
 * Authors: Nate Koelliker, Carlo Antola, Daniel He, Alec Parent, Jake Morrison, Ja-Rey Corcuera
 * University of Utah, CS3505 Final Project
 * Team: StackOverflow Inc.
 */
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <sstream>
#include "json.h"
#include "./Spotify/Spotify.h"
#include "./Spotify/Album.h"

using curl::curl_easy;

/**
 * Returns text from a file (fileName)
 */
std::string GetStringFromFile(std::string fileName)
{
    std::ifstream file(fileName);
    std::stringstream s;
    s << file.rdbuf();
    file.close();
    return s.str();
}

/**
 * Downloads an image from url and saves it as fileName
 */
void DownloadImage(std::string url, std::string fileName)
{
    std::cout << url << std::endl;
    std::ofstream file;
    file.open(fileName);
    curl::curl_ios<std::ostream> writer(file);
    curl_easy easy(writer);
    
    easy.add<CURLOPT_URL>(url.c_str());
    easy.add<CURLOPT_FOLLOWLOCATION>(1L);
    try {
        easy.perform();
    } catch (curl::curl_easy_exception &error) {
		std::cout << error.what() << std::endl;
		error.print_traceback();
    }
    file.close();
}

/**
 * Reads saved Spotify Albums json data and returns two albums released on date
 */
std::vector<std::string> getSpotifyData(std::string date)
{
    std::vector<std::string> data;
    std::vector<Album> albums;
    std::string strData = GetStringFromFile("./Data/spotifyData.txt");
    nlohmann::json jsonData = nlohmann::json::parse(strData)["albums"];
    //Parse json into album objects
    for (const auto &album : jsonData["items"])
    {
        std::string releaseDate = album["release_date"];
        if(releaseDate == date)
            albums.push_back(Album(album));
    }
    //Creates the text to be shown
    for (int i = 0; i < 2; i++)
    {
        std::string info = albums[i].name + " - by " + albums[i].artists + " was released!";
        data.push_back(info);
    }
    //Downloads the album art
    DownloadImage(albums[0].imageUrl, "Spotify_Image_1.jpeg");
    DownloadImage(albums[1].imageUrl, "Spotify_Image_2.jpeg");

    return data;
}

/**
 * Reads saved Stock data and returns stock information from date
 */
std::vector<std::string> getStockData(std::string date)
{
    std::string symbol = "";
    std::string price = "";
    std::string time2;
    std::string time1;
    std::string row;
    std::vector<std::string> subs;
    std::ifstream file("./Data/stockDatabase.txt");
    int count = 0;
    
    while(file >> symbol >> price >> time1 >> time2)
    {
        
        if(count > 1){break;}
     
        if(file.eof()){break;}
        std::string dates = time1 +  " " + time2;
        if(dates < date)
        {
            subs.push_back("The stock " + symbol + " reached $" + price);
        }
        count ++;

    }
    file.close();
    return subs;
}

/**
 * Returns a vector of strings of the bitcoin price for the given day
 * date parameter must be formatted like YYYY-MM-DD
 */
std::vector<std::string> getBitcoinData(std::string date)
{
    // vector of bitcoin prices for given day
    std::vector<std::string> BitcoinData;
    // file to read from
    std::ifstream file("./Data/BitcoinDatabase.txt");
    // read everyline from file
    std::string data;
    while (std::getline(file, data))
    {
        // if the line has the correct day, parse the line and add to bitcoinData.
        // std::string::npos is a static constant value with the greatest possible value
        // for a string, it is used to indicate there is not a match.
        if (data.find(date) != std::string::npos)
        {
            // vector of string to save tokens
            std::vector<std::string> tokens;
            // stringstream class check
            std::stringstream check(data);
            // hold individual token
            std::string token;
            // split into tokens by ' '
            while(std::getline(check, token, ' '))
            {
                tokens.push_back(token);
            }
            BitcoinData.push_back("The bitcoin price moved to $" + tokens[2] + "!");
            std::cout << tokens[2] << std::endl;
        }
    }
    return BitcoinData;
}

/**
 * Reads saved debt data and returns information about the debt on date
 */
std::vector<std::string> getDebtData(std::string date)
{
    std::string symbol = "";
    std::string price = "";
    std::string time2;
    std::string time1;
    std::string row;
    //std::vector<std::vector<std::string>> dataSubtitle;
    std::vector<std::string> subs;
    std::ifstream file("./Data/debtData.txt");
    std::string str;
    while(std::getline(file, str))
    {
        subs.push_back(str);

    }
    file.close();
    return subs;
}

// Adapted from daniel's solution
/**
 * Reads saved steam data and returns information about steam on date
 */
std::vector<std::string> getSteamData(std::string date)
{
    std::string clocktime;
    std::string users;
    std::vector<std::string> data;
    std::ifstream file("./Data/steam.txt");
    
    // guaranteed to follow format, grabs data from oldest to newest
    while(file >> users >> date >> clocktime)
    {
        if(file.eof()){break;}
        data.push_back(users + " Active Steam users on: " + date + " " + clocktime);
    }
    file.close();
    return data;
}

/**
 *  Returns the top three games on Twitch by viewership and its images.
 *  Assumes the date requested is in the form: 2020-12-02 00:35:19
 */
std::vector<std::string> getTwitchData(std::string date1, std::string date2)
{
  std::ifstream file("./Data/twitch.txt");
  std::string line;
  std::vector<std::string> twitchData;
  
  // Loop through each line in twitch.txt
  while (std::getline(file, line))
  {

    //vector of strings to save tokens
    std::vector<std::string> tokens;
    
    // String buffer for line in txt file
    std::stringstream ss(line);
    
    // hold individual token
    std::string token;
    
    // Populate tokens vector with current line
    while(std::getline(ss, token, '_'))
    {
        std::cout << token << std::endl;  
        tokens.push_back(token);
    }
    
    // If any date in twitch.txt matches the first requested date, return the data retrieved at that twitchData
    if(date1.compare(tokens.at(0)) == 0)
    {
     
      twitchData.push_back("1. " + tokens.at(1));
      twitchData.push_back("2. " + tokens.at(3));
      twitchData.push_back("3. " + tokens.at(5));

    }
    // If any date in twitch.txt matches the second requested date, add the data retrieved at that date to twitchData
    else if(date2.compare(tokens.at(0)) == 0)
    {
      twitchData.push_back("1. " + tokens.at(1));
      twitchData.push_back("2. " + tokens.at(3));
      twitchData.push_back("3. " + tokens.at(5));
    }
    
  }
  
  return twitchData;

}

/**
 * Builds the set times at which information should be shown
 */
std::vector<std::string> buildTimes()
{
    std::vector<std::string> times;
    times.push_back("0:00:02.00,0:00:06.00");
    times.push_back("0:00:06.50,0:00:09.00");
    times.push_back("0:00:09.20,0:00:11.80");
    times.push_back("0:00:12.00,0:00:14.00");
    times.push_back("0:00:14.00,0:00:17.00");
    times.push_back("0:00:19.00,0:00:21.80");
    times.push_back("0:00:23.00,0:00:26.20");
    times.push_back("0:00:26.70,0:00:29.00");
    times.push_back("0:00:34.80,0:00:39.00");
    times.push_back("0:00:40.00,0:00:42.10");
    times.push_back("0:00:42.70,0:00:45.50");
    times.push_back("0:00:46.00,0:00:49.00");
    times.push_back("0:00:53.00,0:00:55.00");
    times.push_back("0:00:57.00,0:00:58.50");
    times.push_back("0:00:59.00,0:01:00.00");
    
    return times;
}

/**
 * Generates information for .ass file
 */
std::string buildDialogue(std::string time, std::string text)
{
    std::string s = "Dialogue: 0," + time + ",Common,,0,0,0,," + text;
    return s;
}

/**
 * Gathers data from each source and builds subtitles.ass file
 */
int main() 
{
    std::ofstream file;
    std::string date = "12-4-2020";
    std::string bitcoinDate = "2020-12-04";
    std::string stockd = "04/12/2020 00:00:00";
    std::string twitchd = "2020-12-04 22:10:33";
    std::string twitchd2 = "2020-12-04 00:10:02";


    file.open("subtitles.ass", std::ios::app);
    std::vector<std::string> times = buildTimes();
    std::vector<std::string> bitcoinData = getBitcoinData(bitcoinDate);
    std::vector<std::string> stockData = getStockData(stockd);
    std::vector<std::string> steamData = getSteamData(date);
    std::vector<std::string> spotifyData = getSpotifyData(bitcoinDate);
    std::vector<std::string> twitchData = getTwitchData(twitchd, twitchd2);
    std::vector<std::string> debtData = getDebtData(date);
    
    file << buildDialogue(times[0], "Nate Koelliker  -  Ja-Rey Corcuera") << std::endl;
    file << buildDialogue(times[0], "Alec Parent  -  Jake Morrison") << std::endl;
    file << buildDialogue(times[0], "Daniel He  -  Carlo Antola") << std::endl;
    file << buildDialogue(times[0], "StackOverflow Inc. Team Project") << std::endl;
    file << buildDialogue(times[1], bitcoinData[0]) << std::endl;
    file << buildDialogue(times[2], twitchData[2]) << std::endl;
    file << buildDialogue(times[2], twitchData[1]) << std::endl;
    file << buildDialogue(times[2], twitchData[0]) << std::endl;
    file << buildDialogue(times[2], "Top 3 Twitch Games:") << std::endl;
    file << buildDialogue(times[3], stockData[0]) << std::endl;
    file << buildDialogue(times[4], spotifyData[0]) << std::endl;
    file << buildDialogue(times[5], steamData[0]) << std::endl;
    file << buildDialogue(times[6], debtData[0]) << std::endl;
    file << buildDialogue(times[7], bitcoinData[1]) << std::endl;
    file << buildDialogue(times[8], stockData[1]) << std::endl;
    file << buildDialogue(times[9], twitchData[5]) << std::endl;
    file << buildDialogue(times[9], twitchData[4]) << std::endl;
    file << buildDialogue(times[9], twitchData[3]) << std::endl;
    file << buildDialogue(times[9], "Top 3 Twitch Games:") << std::endl;
    file << buildDialogue(times[10], spotifyData[1]) << std::endl;
    file << buildDialogue(times[11], debtData[1]) << std::endl;
    file << buildDialogue(times[12], steamData[1]) << std::endl;
    file << buildDialogue(times[13], "StackOveflow Inc.'s team grade reached A+!") << std::endl;
    file << buildDialogue(times[14], "Thanks for watching!") << std::endl;
    
    file.close();
    return 0;
}