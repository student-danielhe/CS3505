#include <iostream>
#include <fstream>
using namespace std;

extern "C"
{
 #include <libavcodec/avcodec.h>
 #include <libavutil/imgutils.h>
 #include <libswscale/swscale.h>
 #include <libavformat/avformat.h>
 #include <string>
}

AVFrame* openfile(const char* filename){
  AVFormatContext* Fcontext=NULL;
  int error;
  
  error = avformat_open_input(&Fcontext,filename,NULL,NULL);
  if(error!=0){
    std::cout<<"openfile error"<<std::endl;
    return NULL;
  }
  
  error=avformat_find_stream_info(Fcontext,NULL);
  if(error!=0){
    std::cout<<"sream error"<<std::endl;
    return NULL;
  }
  
  AVCodec *codec=NULL;
  codec=avcodec_find_decoder(Fcontext->streams[0]->codec->codec_id);
  if(codec==NULL){
    std::cout<<"codec error"<<std::endl;
  }
  
  AVCodecContext *Ccontext=Fcontext->streams[0]->codec;
  
  error=avcodec_open2(Ccontext,codec,NULL);
  if(error!=0){
    std::cout<<"opencodec error"<<std::endl;
    return NULL;
  }
  
  AVFrame *frame;
  AVPacket packet;
  frame=av_frame_alloc();
  av_read_frame(Fcontext,&packet);
  int fin;
  avcodec_decode_video2(Ccontext,frame,&fin,&packet);
  
  //av_dump_format(Fcontext,0,"hello",false);
  
  AVFrame *RGB=av_frame_alloc();
  RGB->width=frame->width;
  RGB->height=frame->height;
  RGB->format=AV_PIX_FMT_RGB24;
  int bytes=avpicture_get_size(AV_PIX_FMT_RGB24,Ccontext->width,Ccontext->height);
  
  uint8_t *buffer=(uint8_t*)av_malloc(bytes);
  avpicture_fill((AVPicture*)RGB,buffer,AV_PIX_FMT_RGB24,Ccontext->width,Ccontext->height);
  
  struct SwsContext *Scontext;
  
  Scontext=sws_getContext(frame->width, frame->height,(AVPixelFormat)frame->format,
                          frame->width, frame->height,AV_PIX_FMT_RGB24,
                          SWS_BILINEAR,NULL,NULL,NULL);
  
  sws_scale(Scontext,
            frame->data, frame->linesize, 0, Ccontext->height,
            RGB->data, RGB->linesize);
  
  return RGB;
}
void drawBox(AVFrame *frame,int x, int y, int w, int h, int r, int g, int b){

  for(int i=x;i<x+w;i=i+1){
    for(int j=y;j<y+h;j=j+1){
      frame->data[0][j*frame->linesize[0]+i*3+0]=r;
      frame->data[0][j*frame->linesize[0]+i*3+1]=g;
      frame->data[0][j*frame->linesize[0]+i*3+2]=b;
    }
  }
}
void edit(char* filename, char*outputname,int x, int y, int w, int h, int r, int g, int b){

  AVFrame *frame;
  frame=openfile(filename);
  if(frame==NULL){
    std::cout<<"fail to open"<<std::endl;
    
  }
  std::cout<<frame->width<<std::endl;
  std::cout<<frame->height<<std::endl;
  int color;
  for(color=0; color<3;color=color+1)
  std::cout <<(int)frame->data[0][10*frame->linesize[0]+10*3+color]<<std::endl;
  drawBox(frame,x,y,w,h,r,g,b);
  AVCodec *out=avcodec_find_encoder(AV_CODEC_ID_BMP);
  if(out==NULL){
    std::cout <<"Failed"  << std::endl;
    
  }
  
  AVCodecContext *Ocontext=avcodec_alloc_context3(out);
  if(Ocontext==NULL){
    std::cout << "Failed2" << std::endl;
    
  }
  
  Ocontext->pix_fmt=AV_PIX_FMT_BGR24;
  Ocontext->height=frame->height;
  Ocontext->width=frame->width;
  Ocontext->time_base.num=1;
  Ocontext->time_base.den=1;
  avcodec_open2(Ocontext,out,NULL);
 
  AVPacket packet;
  av_init_packet(&packet);
  packet.data=NULL;
  packet.size=0;
  
  int fin;
  int error;
  error=avcodec_encode_video2(Ocontext,&packet,frame,&fin);
  if(error<0){
    std::cout << "Failed3" << std::endl;
    
  }
  std::cout<<"success"<<std::endl;
  ofstream output(outputname);
  output.write((const char*)packet.data, packet.size);
  output.close();

}
int main(){
  char* filename="transp.jpg";
  char* outputname="test_";
  for (int i=0;i<150;i++){
    
    std::string s=std::to_string(i);
    s=outputname + s + ".bmp";
    
    char arr[s.size()+1];//as 1 char space for null is also required
    strcpy(arr, s.c_str());
    edit(filename, arr ,i*10,0,200,200,0,0,0);
  }
  
  return 0;
}
