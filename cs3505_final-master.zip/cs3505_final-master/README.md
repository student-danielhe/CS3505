# cs3505_final
StackOverflow Inc. Final Team Project
Authors: Nate Koelliker, Ja-Rey Corcuera, Jake Morrison, Daniel He, Carlo Antola, Alec Parent.
University of Utah CS3505 Fall 2020 Final Team Project

Video:
To run our code that creates our video all you need to do is build the docker container from the Dockerfile located in the video folder. After building the 
container, run it and mount it to a directory. Inside the docker container the final video will be located in Main/final.mp4

Data Collection:
Spotify -  In order to run the code to gather data from the Spotify api first you must install curl, cmake, and libcurl. Then go to the curlcpp folder and build it via cmake (run cmake . && make). Once curlcpp is built cd into the Spotify folder and run the same commands (cmake . && make). This will build an executable called spotify. Run this by running ./spotify. In the directory Spotify Data there will be a data.txt file containing the new album releases in json form.

Steam - To run the SteamNumber.py, make sure python and selenium is installed properly, then install a google chrome and chrome webdriver according to the version of browser. Then just make sure the internet connection is stable and  run SteamNumber.py with python and it will print and gather the desired data.

Debt - To run the debt.py, make sure python and selenium is installed properly, then install a google chrome and chrome webdriver according to the version of browser. Then just make sure internet connection is stable and  run the debt.py with python and it will print and gather the desired data.

Bitcoin - To gather the bitcoin data, run in a terminal window the command: python (/location/file.py). This will append data to the txt file.

Twitch - In order to run the code to gather data from the Twitch api, ensure that dotenv is installed on your machine using the command "npm install dotenv". This will allow the JavaScript file to properly run and gain access to the Twitch api. That should be the only package to install so once the JavaScript file runs, it will write to a file called "twitch.txt" and record the current date and the top three games by viewership on Twitch.

Stock - To gather the stock data, run in  a terminal window the command: python ( /location/file.py). This will append data to the txt file. 
