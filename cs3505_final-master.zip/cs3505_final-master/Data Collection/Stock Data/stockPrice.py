# retrieves and stores stock quotes from alphavantage api 
#parses json data to csv and txt file
import requests
import json 
import time 
import csv
from datetime import datetime

API_URL = "https://www.alphavantage.co/query" 
tlsa = 'TSLA'
snp = 'SPY'

dataq = { "function": "GLOBAL_QUOTE",
"symbol": tlsa,
"apikey": "1RIFUFY729PWGTAM" }

#call api with function and stock symbol data
response = requests.get(API_URL, dataq)  
print(response.json())

#parse data 
jres = response.json()
print(jres["Global Quote"]["05. price"])
price = jres["Global Quote"]["05. price"]
now = datetime.now()
timed = now.strftime("%d/%m/%Y %H:%M:%S")

#append to list and write to csv and txt file
dataList = []
dataList.append(snp)
dataList.append(price)
dataList.append(timed)
myFile = open('/home/ec2-user/environment/CarloFolder/stockDatabase.csv', 'a')
with myFile:
    writer = csv.writer(myFile)
    writer.writerow(dataList)
    
with open('/home/ec2-user/environment/CarloFolder/stockDatabase.txt', 'a') as f:
    f.write(" ".join(dataList))
    f.write("\n")
    
