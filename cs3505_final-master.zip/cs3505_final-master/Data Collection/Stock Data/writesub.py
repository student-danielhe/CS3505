import csv
import sys

def main():
        quote = sys.argv[1]
        quote = quote + " "+ sys.argv[2]
        subtlist = []
        with open('stockDatabase.csv', newline='') as csvfile:
                reader = csv.reader(csvfile, delimiter=',')
                for row in reader:                        
                        if row[2] > quote:
                                subtlist.append(row[0] + " " + row[1])
        subtitle = "Dialogue: 0,0:01:00.00,0:01:15.84,Default,,0000,0000,0000,,"
        subtitle = subtitle + subtlist[0]
        f = open("subt.ass", "a")
        f.write(subtitle + "\n")
        f.close()

if __name__ == "__main__":
    main()
                                

