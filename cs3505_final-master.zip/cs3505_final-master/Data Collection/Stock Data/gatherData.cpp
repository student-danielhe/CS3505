#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
std::vector<std::string> createSubtitle(std::string date);
    
    
std::vector<std::string> createSubtitle(std::string date)
{
    std::string symbol = "";
    std::string price = "";
    std::string time2;
    std::string time1;
    std::string row;
    //std::vector<std::vector<std::string>> dataSubtitle;
    std::vector<std::string> subs;
    std::ifstream file("/home/ec2-user/environment/CarloFolder/stockDatabase.txt");
    int count = 0;
    
    while(file >> symbol >> price >> time1 >> time2)
    {
        //std::getline(file,row, '\n');
        if(count > 2){break;}
       // std::cout << time1 << time2 << " comp" << date << std::endl;
        if(file.eof()){break;}
        std::string dates = time1 +  " " + time2;
        if(dates < date)
        {
            
            subs.push_back(symbol + " " + price);
            std::cout << subs[0] << std::endl;
        }
        count ++;

    }
    file.close();
    
    return subs;
    
}

int main()
{
    createSubtitle("2/13/2020 00:00:00");
}
