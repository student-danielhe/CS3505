#include <string.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
#include <iterator>

int main()
{
  std::ifstream file("twitch.txt");
  std::string date = "2020-12-02 00:35:19";
  std::string data;
  std::vector<std::string> testData;
  
  while (std::getline(file, data))
  {

    //vector of strings to save tokens
    std::vector<std::string> tokens;
    
    // String buffer for line in txt file
    std::stringstream ss(data);
    
    // hold individual token
    std::string token;
    
    // Populate tokens vector with current line
    while(std::getline(ss, token, '_'))
    {
        std::cout << token << std::endl;  
        tokens.push_back(token);
    }
    
    //
    if(date.compare(tokens.at(0)) == 0)
    {
      std::cout << "FOUND DATE" << std::endl;
  //  testData.push_back("1. " + tokens.at(1) + " 2. " + tokens.at(3) + " 3. " + tokens.at(5));
      testData.push_back("1. " + tokens.at(1) + " " + tokens.at(2));
      testData.push_back("2. " + tokens.at(3) + " " + tokens.at(4));
      testData.push_back("3. " + tokens.at(5) + " " + tokens.at(6));
      std::cout << testData.at(0);
      return;
    }
  }
  
  throw std::invalid_argument("Date requested was not found in twitch.txt!");


}