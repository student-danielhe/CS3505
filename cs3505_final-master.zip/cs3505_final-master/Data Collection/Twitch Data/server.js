#! /home/ec2-user//.nvm/versions/node/v10.23.0/bin/node
/**
 * Obtains the top 3 games on Twitch by viewership
 * Author: Ja-Rey Corcuera
 */


require('dotenv').config();
const request = require('request');

/**
 * Function that contacts Twitch's API and extracts the top 10 games in JSON form.
 * 
 * @param {url to access data} url 
 * @param {token to access twitch api} accessToken 
 * @param {not used} callback 
 */
const getGames = (url, accessToken, callback) => {

    // Setup properties to access twitch API
    const gameOptions = {
        url: process.env.GET_GAMES,
        method: 'GET',
        headers: {
            'Client-ID':process.env.CLIENT_ID,
            'Authorization': 'Bearer ' + process.env.ACCESS_TOKEN
        }
    };

    // Gets the data from twitch's api
    request.get(gameOptions, (err, res, body) => {
        if(err){
            return console.log(err);
        }

        // Parse the JSON data
        var twitchData = JSON.parse(body);


        // Record the currrent date of this program execution
        var currentDate = new Date();
        var Seconds = currentDate.getSeconds();
        var Minutes = currentDate.getMinutes();
        var Hours = currentDate.getHours();
        var Day = (currentDate.getDay());

        // Format dates correctly if needed
        if(currentDate.getSeconds().toString().length == 1)
        {
            Seconds = "0" + currentDate.getSeconds();
        }
        if(currentDate.getMinutes().toString().length == 1)
        {
            Minutes = "0" + currentDate.getMinutes();
        }
        if(currentDate.getHours().toString().length == 1)
        {
            Hours = "0" + currentDate.getHours();
        }
        if(currentDate.getDay().toString().length == 1)
        {
            Day = "0" + (currentDate.getDay());
        }

        // Create the final string which includes the date and top 3 games with their .jpg images
        var date = currentDate.getFullYear() + "-" + (currentDate.getMonth()+1) + "-" + (Day) + " " + Hours + ":" + Minutes + ":" + Seconds;
        var str = twitchData["data"][0]["name"] + "_" + twitchData["data"][0]["box_art_url"] + "_" + twitchData["data"][1]["name"] + "_" + twitchData["data"][1]["box_art_url"] + "_" + twitchData["data"][2]["name"] + "_" + twitchData["data"][2]["box_art_url"];
        var TopGames = date + "_" + str.replace(new RegExp('{width}', 'g'), "160").replace(new RegExp('{height}', 'g'), "210") + "\n";
        // Append the string to the twitch.txt
        const fs = require('fs');
        fs.appendFile('twitch.txt', TopGames, (err) => {
            if(err) {
                throw err;
            }

            console.log("Data has been appended to twitch.txt.");
        });
    });
};

// Call the GetGames function
getGames(process.env.GET_GAMES, process.env.ACCESS_TOKEN, (response) => {})


