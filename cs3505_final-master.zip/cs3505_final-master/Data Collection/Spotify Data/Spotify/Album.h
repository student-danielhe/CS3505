/**
 * Author: Nate Koelliker
 * Album object
 */

#ifndef SPOTIFY_ALBUM
#define SPOTIFY_ALBUM

#include "json.h"
#include <string>
#include <vector>

class Album
{
        
    public:
        std::string artists;
        std::string imageUrl;
        std::string name;
        std::string releaseDate;
        Album(nlohmann::json albumInfo);

};



#endif