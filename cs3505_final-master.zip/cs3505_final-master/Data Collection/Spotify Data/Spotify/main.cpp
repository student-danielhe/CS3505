/**
 * Main
 * Author: Nate Koelliker
 */
#include "Spotify.h"
#include "Album.h"

/**
 * Main
 * Creates a Spotify object and pulls the data 
 */
int main()
{
    Spotify spotify;
    spotify.PullData();
    return 0;
}
