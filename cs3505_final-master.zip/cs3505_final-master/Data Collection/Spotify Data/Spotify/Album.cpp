/**
 * Author: Nate Koelliker
 * Album object 
 */

#include "Album.h"

/**
 * Album constructor
 * Reads json data and populates Album fields
 */
Album::Album(nlohmann::json data)
{
    this->artists = data["artists"][0]["name"];
    for(int i = 1; i < data["artists"].size(); i++)
    {
        std::string artist = data["artists"][i]["name"];
        this->artists += " & " + artist;
    }
    this->imageUrl = data["images"][1]["url"];
    this->name = data["name"];
    this->releaseDate = data["release_date"];
}




