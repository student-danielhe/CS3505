/**
 * Author: Nate Koelliker
 * Spotify object
 */
#include "Spotify.h"

using curl::curl_easy;

/**
 * Pulls the data from the Spotify API via curl 
 */
void Spotify::PullData()
{
    //Tokens
    std::string refreshToken = GetStringFromFile("./refresh_token.txt");
    std::string authCode = GetStringFromFile("./authcode.txt");
    std::string clientIdSecret = GetStringFromFile("./client_id_secret.txt");
    std::ostringstream stream; //Response stored in stream
    curl::curl_ios<std::ostringstream> ios(stream);
    //Builds http request header
    curl_easy easy(ios);
    curl::curl_header header;
    header.add("Authorization: Bearer " + authCode);

    easy.add<CURLOPT_HTTPHEADER>(header.get());
    easy.add<CURLOPT_URL>("https://api.spotify.com/v1/browse/new-releases?offset=0&limit=50");
    easy.add<CURLOPT_CUSTOMREQUEST>("GET");

    try
    {
        easy.perform();
        auto x = easy.get_info<CURLINFO_RESPONSE_CODE>();
        if (x.get() == 401)
        {
            //Access token has expired and needs to be refreshed
            std::cout << "Http response code is 401" << std::endl;
            UpdateAccessToken(refreshToken, clientIdSecret);
            return;
        }
        SaveData(stream.str()); //Saves the data
    }
    catch (curl::curl_easy_exception error)
    {
        std::cout << error.what() << std::endl;
        error.print_traceback();
    }
}

/**
 * Updates the expired access token through Spotify API and saves them to their files
 */ 
void Spotify::UpdateAccessToken(std::string refreshToken, std::string clientIdSecret)
{
    //Reponse stored in stream
    std::ostringstream stream;
    curl::curl_ios<std::ostringstream> ios(stream);
    //Builds http request header
    curl_easy easy(ios);
    curl::curl_header header;
    header.add("Authorization: Basic " + clientIdSecret);
    std::string postData = "grant_type=refresh_token&refresh_token=" + refreshToken;

    easy.add<CURLOPT_HTTPHEADER>(header.get());
    easy.add<CURLOPT_URL>("https://accounts.spotify.com/api/token");
    easy.add<CURLOPT_CUSTOMREQUEST>("POST");
    easy.add(curl::curl_pair<CURLoption, std::string>(CURLOPT_POSTFIELDS, postData));

    try
    {
        easy.perform();
        nlohmann::json response = nlohmann::json::parse(stream.str());
        PutStringInFile("./authcode.txt", response["access_token"]);
        PullData(); //Calls pull data again after getting new tokens
    }
    catch (curl::curl_easy_exception error)
    {
        std::cout << error.what() << std::endl;
        error.print_traceback();
    }
}

/**
 * Saves a string to a file
 */ 
void Spotify::PutStringInFile(std::string fileName, std::string newString)
{
    std::ofstream file(fileName);
    file << newString;
    file.close();
}

/**
 * Saves the string data to the file data.txt
 */ 
void Spotify::SaveData(std::string data)
{
    std::ofstream file;
    file.open("data.txt");
    file << data << std::endl;
    file.close();
}

/**
 * Gets a string from a file
 */ 
std::string Spotify::GetStringFromFile(std::string fileName)
{
    std::ifstream file(fileName);
    std::stringstream s;
    s << file.rdbuf();
    file.close();
    return s.str();
}