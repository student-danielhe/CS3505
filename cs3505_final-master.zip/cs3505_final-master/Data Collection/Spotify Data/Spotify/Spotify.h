/**
 * Author: Nate Koelliker
 * Spotify object
 */
#ifndef SPOTIFY
#define SPOTIFY

#include <fstream>
#include "curl_easy.h"
#include "curl_header.h"
#include "curl_ios.h"
#include "Album.h"
#include <iostream>
#include <string>
#include <sstream>
#include "json.h"


class Spotify
{
    public:
        void PullData();

    private:
        void UpdateAccessToken(std::string refreshToken, std::string clientIdSecret);
        void PutStringInFile(std::string fileName, std::string newString);
        void SaveData(std::string data);
        std::string GetStringFromFile(std::string fileName);
};

#endif