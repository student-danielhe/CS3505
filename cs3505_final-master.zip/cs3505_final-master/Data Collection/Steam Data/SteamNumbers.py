# Modified from Daniel's solution

# code from https://medium.com/@praneeth.jm/running-chromedriver-and-selenium-in-python-on-an-aws-ec2-instance-2fb4ad633bb5
from selenium import webdriver
import time 
import csv
from datetime import datetime
from selenium.webdriver.chrome.options import Options

options = Options()
options.headless = True
driver = webdriver.Chrome(options=options)

# end copied code

driver.get("https://store.steampowered.com/stats/")
print("Current online Steam users:")
for x in driver.find_elements_by_xpath('/html/body/div[1]/div[7]/div[4]/div[1]/div[2]/div[2]/div/div[2]/div[2]/table/tbody/tr[2]/td[2]/span'):
    print(x.text)
    nums = x.text
driver.close
now = datetime.now()
timed = now.strftime("%d/%m/%Y %H:%M:%S")

# Daniel's file IO
dataList = []
dataList.append(nums)
dataList.append(timed)
myFile = open('steam.csv', 'a')
with myFile:
    writer = csv.writer(myFile)
    writer.writerow(dataList)

with open('/home/ec2-user/environment/main/data/steam.txt', 'a') as f:
    f.write(" ".join(dataList))
    f.write("\n")