import time
import csv
from datetime import datetime
i =0;
while i<100:
    time.sleep(60)
    now = datetime.now()
    timed = now.strftime("%d/%m/%Y %H:%M:%S")
    dataList = []
    dataList.append(i)
    dataList.append(timed)
    myFile = open('debt.csv', 'a')
    i=i+1;
    print(i)
    with myFile:
        writer = csv.writer(myFile)
        writer.writerow(dataList)
