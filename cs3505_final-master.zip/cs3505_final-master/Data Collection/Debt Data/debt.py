DRIVER_PATH = '/home/ec2-user/environment/MarioChrome/chromedriver.exe'
from selenium import webdriver
import time 
import csv
from datetime import datetime
from selenium.webdriver.chrome.options import Options

options = Options()
options.headless = True
driver = webdriver.Chrome(options=options)

driver.get('https://www.usdebtclock.org/world-debt-clock.html')
print("Current US Debt is:")
print(driver.find_element_by_id("layer3").text)

debt=driver.find_element_by_id("layer3").text
now = datetime.now()
timed = now.strftime("%d/%m/%Y %H:%M:%S")

dataList = []
dataList.append(debt)
dataList.append(timed)
myFile = open('debt.csv', 'a')
with myFile:
    writer = csv.writer(myFile)
    writer.writerow(dataList)
with open('/home/ec2-user/environment/DanielFolder/debtData.txt', 'a') as f:
    f.write("By the time ")
    f.write(timed)
    f.write(" ,the Us debt have increased to ")
    f.write(debt)
    f.write("! \n")